package com.raisya.nilai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NilaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
