package com.raisya.latihan1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Latihan1Application {

	public static void main(String[] args) {
		SpringApplication.run(Latihan1Application.class, args);
	}

}
